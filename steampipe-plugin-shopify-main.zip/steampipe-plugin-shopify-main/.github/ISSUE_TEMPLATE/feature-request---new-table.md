---
name: Feature request - New table
about: Suggest a new table for this project
title: Add table shopify_<service>_<resource>
labels: enhancement, new table
assignees: ''

---

**References**
Add any related links that will help us understand the resource, including vendor documentation, related GitHub issues, and Go SDK documentation.
